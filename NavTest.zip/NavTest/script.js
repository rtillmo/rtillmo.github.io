$(document).ready(function() {
   $(".navbar-toggler",".overlay").on("click", function() {
       $(".mobile-menu", ".overlay").toggleClass("open");
   });
});